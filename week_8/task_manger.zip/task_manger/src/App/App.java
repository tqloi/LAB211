
package App;

import view.TaskView;

public class App {
    public static void main(String[] args) {
        new TaskView().run();
    }
}
